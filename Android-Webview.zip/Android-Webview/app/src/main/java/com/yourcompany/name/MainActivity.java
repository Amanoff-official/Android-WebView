package com.yourcompany.name;

import android.annotation.*;
import android.app.*;
import android.os.*;
import android.webkit.*;
import android.view.*;
import android.widget.Toast;
import android.content.Intent;
import android.net.Uri;

public class MainActivity extends Activity {

    private WebView mWebView;
    private String homeUrl = "https://example.com"; // URL baş sahypa

    @Override
    @SuppressLint("SetJavaScriptEnabled")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        mWebView = findViewById(R.id.webview);
        WebSettings webSettings = mWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        mWebView.setWebViewClient(new TkmWebViewClient());
        mWebView.loadUrl(homeUrl);
    }

    private class TkmWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(final WebView view, final String url) {
            if (url.contains("t.me") || url.contains("tmstart.me") || url.contains("linkm.me")) {
                // By saýtlary brawzerde açýa
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
                view.loadUrl(homeUrl);
                return true;
            }
            return false;
        }
    }

    @Override
    public void onBackPressed() {
        if (mWebView.canGoBack()) {
            mWebView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
